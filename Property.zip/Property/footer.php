 <div class="footer">
      <div class="text">2016 All Rights Reserved. </div>
	  

    </div>
