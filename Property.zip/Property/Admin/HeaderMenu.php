<div class="header">
    <div class="header1"><img src="images/logo.jpg" width="229" height="36" /></div>
    <div class="header2">
      <div id="container">
        <div id="mainmenu">
          <ul>
            <li><a class="current a" href="index.php">Home</a></li>
            <li><a  href="Property.php" class="a">Property</a></li>
             <li><a  href="News.php" class="a">News</a></li>
            <li><a href="Logout.php" class="a">Logout</a></li>
           
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="headerimage">
    <div class="headeriamge1">
      <div class="house"></div>
    </div>
    <div class="headerimage2">
     
    </div>
    <div>
    
    </div>
  </div>