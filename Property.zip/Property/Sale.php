<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Real Estate</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="css/style1.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style3 {
	color: #FFFFFF;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: small;
}
.style6 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: small; }
.style8 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: small; font-weight: bold; }
.style9 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style10 {font-size: small}
-->
</style>
</head>
<body>
<div class="main">
  <?php
  include "Headermenu.php"
  ?>
  <div class="content">
    <div class="innercontent">
      <?php
	  include "left.php"
	  ?>
      <div class="rightpannel">
      <div>
      <br/>
      <table width="100%" height="205" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td bgcolor="#7E9020"><span class="style3">Sale Property</span></td>
        </tr>
        <tr>
          <td height="30"><span class="style8"><img src="images/grid.gif" width="3" height="3" /> Here You can Sale Your Property.</span></td>
        </tr>
        <tr>
          <td><span class="style8"><img src="images/grid.gif" width="3" height="3" /> In Order to Sale any of Your Property, First You have to Register on this Web Portal.</span></td>
        </tr>
        <tr>
          <td height="32"><span class="style8"><img src="images/grid.gif" width="3" height="3" /> Once You Registered on the Portal, You will receive UserName and Password.</span></td>
        </tr>
        <tr>
          <td height="34"><span class="style8"><img src="images/grid.gif" width="3" height="3" /> Once You Login into the System, You can upload the details of your property. </span></td>
        </tr>
        <tr>
          <td height="39"><div align="center" class="style9"><a href="register.php" class="style10">Click Here to Register</a></div></td>
        </tr>
      </table>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      </div>
        
      </div>
    </div>
  </div>
  <div>
   <?php
   include "footer.php"
   ?>
  </div>
</div>
</body>
</html>
